
import Data.List
import Data.Char
import Data.Maybe
import Numeric
import Control.Monad

import System.Environment hiding (getEnv)


main :: IO ()

main = 
    do  environment <- getEnvironment
	
        -- read from stdin if data is available
        let content_length = (getEnv environment "CONTENT_LENGTH") 
        post_data <- if   (isJust content_length) 
                     then readPost (fst $ head $ readDec $ fromJust content_length)
                     else return ""
        
        -- print html
        putStr ("Content-type: text/html\n\n" ++ process environment post_data)

type Environment = [(Key,Value)]
type PostData = String
type HTML = String

process :: Environment -> PostData -> HTML

process environment post_data
    | given "ENV"     = (html_environment environment)
    | given "PARAM"   = (html_params get_params)
    | given "POST"    = html_postrequest post_params post_data
    | otherwise       = html
    where query        = getEnv environment "QUERY_STRING"
          get_params   = toParams (fromMaybe "" query)
          post_params  = toParams post_data
          given key    = (getParam get_params key) /= [] 


type Tagging   = String -> String

type Key       = String
type Value     = String
type Attribute = (Key, Value)

html_tag :: String -> [Attribute] -> Tagging

html_tag name attrs content =
    "<" ++ name ++ expanded_attrs ++ ">" ++ content ++ "</" ++ name ++ ">"
    where expanded_attrs = concat [ " " ++ attr ++ "=\"" ++ value ++ "\"" | (attr, value) <- attrs ]

html_etag :: String -> Tagging

-- empty tag
html_etag name content =
    html_tag name [] content

html_h1 header =
    html_etag "h1" header

html_p content =
    html_etag "p" content

html_pre = html_etag "pre"

html_eetag :: String -> String

-- very empty
html_eetag name =
    html_tag name [] ""

html_br = html_eetag "br"

html_doc title content =
    html_etag "html" (
        html_etag "head" (
            html_etag "title" title
        )
        ++
        html_etag "body" (
            (html_h1 title)
            ++
            content
        )
    )

html = 
    html_doc "Hello world!" "TADA!!"


------------------------------------

-- type Environment = [(Key,Value)]

getEnv :: Environment -> Key -> (Maybe Value)

getEnv environ key =
    if matched then (Just value)
               else Nothing
    where match   = filter ( \(k,v) -> k == key ) environ
          matched = match /= []
          value   = snd $ head match



html_wrap tag items = concat [ tag item | item <- items ] 

(<°##><) = html_wrap


html_table header rows =
    html_etag "table" (
        (html_etag "tr") <°##>< (    
            [ (html_etag "th") <°##>< header ] ++
            [ (html_etag "td") <°##>< row | row <- rows ]
        )
    )


html_environment env =
    html_doc "Environment" (
        html_table ["Key","Value"] [ [k,v] | (k,v) <- env ]
    )

--------------------------------------

type Parameter = (Key, Value)

toParams :: String -> [Parameter]

toParams ""    = []
toParams query = (toParam param):(toParams restquery)
                 where (param, rest) = break ('&' ==) query
                       restquery     = drop 1 rest


toParam :: String -> Parameter

toParam param = (cleanParam key,cleanParam value)
                where (key,rest) = break ('=' ==) param
                      value      = drop 1 rest


dehex hex = if parsed then num 
                      else (-1)
            where extract = readHex hex
                  parsed  = case extract of
                                [(_,"")] -> True
                                _        -> False
                  num     = fst $ head extract


cleanParam :: String -> String

cleanParam ""       = ""
cleanParam ('+':xs) = ' ':(cleanParam xs)
cleanParam ('%':xs) = case xs of
                        (d1:d2:rest) -> if ok then char:(cleanParam rest)
                                              else '%':(cleanParam (d1:d2:rest))
                                        where num  = dehex (d1:d2:"")
                                              ok   = num /= -1
                                              char = if num < 128 then (chr num) else '?'
                        rest         -> '%':(cleanParam rest)
cleanParam (x:xs)   = x:(cleanParam xs)


type Name = String

getParam :: [Parameter] -> Name -> [Value]

getParam params key = map (snd) (filter (\(k,v) -> k == key) params)


html_params params =
    html_doc "Params" (
        html_table ["Key","Value"] [ [k,v] | (k,v) <- params ]
    )


--------------------------------------

readPost :: Integer -> IO PostData

readPost num = do post_data <- (replicateM (fromIntegral num) getChar)
                  return post_data 


html_form method content = html_tag "form" [("method",method)] content

html_label caption content = caption ++ ":&nbsp;" ++ content

html_textfield name = html_tag "input" [("type","text"),("name",name)] ""

html_hidden name value = html_tag "input" [("type","hidden"),("name",name),("value",value)] ""

html_submit caption = html_tag "input" [("type","submit"),("name","submit"),("value",caption)] ""


html_postrequest post_params post_string = 
    html_doc "POST test" (
        (html_form "post" (
            html_label "Hier tippen" ( 
                (html_textfield "eingabe") ++ (html_submit "awesome!") )
                ++ html_br ++
            html_label "POST String" (html_pre post_string) ++ html_br ++
            (html_hidden "eingabe" <°##>< items) ++
            (html_etag "ul" ( html_etag "li" <°##>< items ))
        )) ++ 
        flush_button
    )
    where items        = getParam post_params "eingabe"
          flush_button = if items == [] then ""
                                        else (html_form "post" (html_submit "flush-o-matic(tm)"))       

